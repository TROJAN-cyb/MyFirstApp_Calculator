
A sleek Flutter scientific calculator handling simple to advanced math ops with ease 

# Features
- Basic math: `+`, `-`, `*`, `/`
- Trig functions: sin, cos, tan, asin, acos, atan
- Hyperbolic functions: sinh, cosh, tanh
- Logarithmic calculations: log, ln
- Exponents and roots: x², x³, √x, 1/x
- Combinatorial functions: factorial, nPr, nCr
- Mathematical constants: π, e
- Degree/Radian mode switching
- Percentage calculations, sign inversion, clear and backspace controls

# State Management
This project utilizes Provider for efficient state management and UI updates 🚀

# Getting Started
1. Run `flutter pub get` to install dependencies
2. Run `flutter run` to launch the application

# Requirements
- Flutter SDK version 3.x
- Dart SDK version 3.x
